# Heart-Disease-Analysis-and-Prediction-Front-End

See project site at [byte7.github.io](http://byte7.github.io/projects/heart_disease_analysis/index.html) for a description of the results.

This repository contains source code for entire Front End for Heart Disease Analysis and Prediction Project.
The Front End is made with HTML, CSS and JavaScript. We have used various JavaScripts for look and feel.

The jupyter notebooks of the analysis can be viewed [here](https://github.com/Byte7/Heart-Disease-Analysis-and-Prediction).
